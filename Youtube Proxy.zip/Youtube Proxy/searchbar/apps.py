from django.apps import AppConfig


class SearchbarConfig(AppConfig):
    name = 'searchbar'
