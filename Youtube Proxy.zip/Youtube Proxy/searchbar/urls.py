# searchbar/urls.py

from django.urls import path
from . import views

app_name = 'searchbar'
urlpatterns = [
    path('videodata/', views.videodata, name='videodata'),
     path('<str:videoid>/',views.player, name='player'),
    
    # ... other patterns
]
