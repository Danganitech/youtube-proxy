from django.contrib.auth.decorators import login_required
from django.shortcuts import render, redirect
from django.contrib import messages
from django.conf import settings
from datetime import datetime
from history.models import VideoHistory
import requests
from playlist.models import Playlist
from requests import get
from isodate import parse_duration


video_url = 'https://www.googleapis.com/youtube/v3/videos'
search_url = 'https://www.googleapis.com/youtube/v3/search'
search_params = {
    'type': 'video',
    'maxResults': 30,
    'part': 'snippet',
    'videoEmbeddable': True,
    'key': settings.YOUTUBE_API_KEY,
}

@login_required
def videodata(request):
    required_data = []
    if request.method == "POST":
        search_parameters = {
            'key': settings.YOUTUBE_API_KEY,
            'part': 'snippet',
            'q': request.POST['searchbar'],
            'type': 'video',
            'videoEmbeddable': True,
            'maxResults': 30,
        }

        try:
            response = requests.get(search_url, params=search_parameters)
            response.raise_for_status()  # Check for request success
            fetched_data = response.json().get('items', [])
        except requests.exceptions.RequestException as e:
            messages.error(request, f'Error fetching data from YouTube API: {e}')
            return render(request, 'index.html', {'videos': None, 'history': []})

        video_id_list = []
        video_id_title_list = []
        for data in fetched_data:
            video_id = data['id']['videoId']
            video_id_list.append(video_id)
            title = data['snippet']['title']
            video_id_title_list.append((video_id, title))

        video_parameters = {
            'key': settings.YOUTUBE_API_KEY,
            'part': 'snippet,contentDetails,statistics',
            'id': ','.join(video_id_list),
        }

        try:
            response = requests.get(video_url, params=video_parameters)
            response.raise_for_status()  # Check for request success
            video_data = response.json().get('items', [])
        except requests.exceptions.RequestException as e:
            messages.error(request, f'Error fetching video data from YouTube API: {e}')
            return render(request, 'index.html', {'videos': None, 'history': []})

        for i in range(min(search_parameters['maxResults'], len(video_data))):
            video_id, title = video_id_title_list[i]
            VideoHistory.objects.get_or_create(
                user=request.user,
                video_id=video_id,
                title=title,
                category='watched',
            )

            views = formatted_views(video_data[i]['statistics']['viewCount'])
            try:
                thumbnail = video_data[i]['snippet']['thumbnails']['standard']['url']
            except KeyError:
                thumbnail = video_data[i]['snippet']['thumbnails']['high']['url']

            videos = {
                'id': video_id,
                'title': video_data[i]['snippet']['title'],
                'description': video_data[i]['snippet']['description'],
                'thumbnail': thumbnail,
                'duration': str(int(parse_duration(video_data[i]['contentDetails']['duration']).total_seconds() // 60)) + ' mins',
                'views': views + ' views',
            }
            required_data.append(videos)

    history_data = VideoHistory.objects.filter(user=request.user)

    return render(request, 'index.html', {'videos': required_data, 'history': history_data})

'''def videodata(request):
    if request.method == 'POST':
        search_params['q'] = request.POST.get('searchbar')

        try:
            response = requests.get(search_url, search_params)
            response.raise_for_status()

            data = response.json() #.get('items', [])
            print(data)
        except requests.exceptions.RequestException as e:
            ...
        return redirect('/videodata/videodata')
    return render(request, 'index.html')
'''    

def formatted_views(views):
    videos = None
    views = int(views)
    index = 0
    while views > 1000:
        index += 1
        views /= 1000

    if int(views) >= 10:
        views = int(views)
        return f'{views}{["", "K", "M", "B"][index]}'
    else:
        return f'{views:.1f}{["", "K", "M", "B"][index]}'

def player(request, videoid):
    video_parameters = {
        'key': settings.YOUTUBE_API_KEY,
        'part': 'snippet,contentDetails,statistics',
        'id': videoid,
    }

    try:
        response = requests.get(video_url, params=video_parameters)
        response.raise_for_status()  # Check for request success
        video_data = response.json().get('items', [])
        print(video_data)  # Add this line to print the response

        if not video_data:
            raise KeyError("No items found in the response.")

        date = str(video_data[0]['snippet']['publishedAt']).split('T')[0]
        date = datetime.fromisoformat(date)
        month = date.strftime('%b')
        videos = {
            'id': videoid,
            'title': video_data[0]['snippet']['title'],
            'date': f'Uploaded on {month} {date.day}, {date.year}',
            'views': video_data[0]['statistics']['viewCount'] + ' views',
        }
    except KeyError as e:
        # Handle the case where 'items' or some expected key is missing in the response
        messages.error(request, f'Error fetching video data from YouTube API: {e}')

    playlists= Playlist.objects.filter(user=request.user)
    context = {'videos': videos, "playlists":playlists}
    return render(request, 'videoplayer.html', context)
