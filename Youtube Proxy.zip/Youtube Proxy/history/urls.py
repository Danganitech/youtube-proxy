from django.urls import path
from . import views

app_name="history"
urlpatterns = [
    path('', views.history_list, name='history_list'),
    path('<str:category>/', views.history_list, name='history_list_with_category'),
    path('delete/<int:pk>/', views.delete_history_entry, name='delete_history_entry'),
]
