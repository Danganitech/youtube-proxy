from . import models
from django.contrib import admin

# Register your models here.
@admin.register(models.Video)
class VideoAdmin(admin.ModelAdmin):
    list_display = ['name']
    search_fields = ['name']

@admin.register(models.VideoHistory)
class VideoHistoryAdmin(admin.ModelAdmin):
    list_display = ['title', 'viewed_at' ]
    search_fields = ['name']