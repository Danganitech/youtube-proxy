# history/views.py
from django.shortcuts import render, get_object_or_404, redirect
from history.models import VideoHistory
from django.contrib.auth.decorators import login_required

@login_required
def history_list(request, category=None):
    history_entries = VideoHistory.objects.filter(user=request.user)

    if category:
        history_entries = history_entries.filter(category=category)

    history_entries = history_entries.order_by('-viewed_at')
    return render(request, 'history/history_list.html', {'history': history_entries})


@login_required
def delete_history_entry(request, pk):
    entry = get_object_or_404(VideoHistory, pk=pk, user=request.user)
    entry.delete()
    return redirect('history:history_list')
