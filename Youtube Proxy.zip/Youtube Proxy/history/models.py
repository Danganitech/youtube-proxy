# history/models.py
from django.db import models
from account.models import CustomUser

class Video(models.Model):
    name = models.CharField(max_length=255)
    # other fields for your Video model

    def __str__(self):
        return self.name

class VideoHistory(models.Model):  # Update the model name to VideoHistory
    user = models.ForeignKey(CustomUser, on_delete=models.CASCADE)
    video_id = models.CharField(max_length=255)  # Make it unique
    title = models.CharField(max_length=255)  # Add this line for the title field
    viewed_at = models.DateTimeField(auto_now_add=True)
    category = models.CharField(max_length=255, blank=True, null=True)

    def __str__(self):
        return f'{self.user.username} viewed video {self.video_id} on {self.viewed_at} in category {self.category}'
