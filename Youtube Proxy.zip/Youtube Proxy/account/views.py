from .forms import CustomUserCreationForm
from django.shortcuts import render, redirect
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth import authenticate, login,logout
from django.contrib.auth.decorators import login_required

from django.urls import path
from django.contrib.auth import views as auth_views

urlpatterns = [
    # Other URL patterns...
    path('reset/<uidb64>/<token>/', auth_views.PasswordResetConfirmView.as_view(), name='password_reset_confirm'),
    # Other URL patterns...
]


def signup(request):
    if request.method == 'POST':
        form = CustomUserCreationForm(request.POST)
        if form.is_valid():
            form.save()
            username = form.cleaned_data.get('username')
            raw_password = form.cleaned_data.get('password1')
            user = authenticate(username=username, password=raw_password)
            login(request, user)
            return redirect('index')  # Redirect to the desired page after successful signup
    else:
        form = CustomUserCreationForm()

    return render(request, 'account/signup.html', {'form': form})


def login_view(request):
    if request.method == 'POST':
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            print(f"Username: {username}, Password: {password}")
            user = authenticate(username=username, password=password)

            if user is not None:
                login(request, user)
                print("User authenticated successfully")
                print(f"Redirecting to index. User: {user}")
                return redirect('index')
            else:
                # Authentication failed, add an error message if needed
                form.add_error(None, 'Invalid username or password')
                print("Authentication failed")
        else:
            # Log form errors for troubleshooting
            print("Form is not valid")
            print(form.errors)
            print(form.non_field_errors())
    else:
        # Handle the case where the request method is not POST
        print("Not a POST request")
        form = AuthenticationForm()

    # Render the login form with the provided form instance
    return render(request, 'account/login.html', {'form': form})


def google_signup(request):
    # This view will handle the Google sign-up process
    # It redirects the user to Google's authentication endpoint
    return redirect('social:begin', 'google-oauth2')

def logout_view(request):
    logout(request)
    return redirect('index')  # Update the 'index' to the appropriate name or URL

@login_required
def index(request):  # Added 'request' parameter
    return render(request, 'index.html')  # Added 'request' parameter
from django.contrib.auth.forms import PasswordResetForm

# Import other necessary modules

def forgot_password(request):
    if request.method == 'POST':
        form = PasswordResetForm(request.POST)
        if form.is_valid():
            form.save(request=request)
            # Redirect to a page indicating that an email has been sent with instructions
            return redirect('login')  # Redirect to the login page after password reset request
    else:
        form = PasswordResetForm()
    return render(request, 'account/forgot_password.html', {'form': form})

# Update urlpatterns
