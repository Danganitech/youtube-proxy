from django.urls import path
from django.contrib.auth import views as auth_views
from .views import signup, login_view, google_signup, logout_view, index, forgot_password

urlpatterns = [
    path('signup/', signup, name='signup'),
    path('login/', login_view, name='login'),
    path('google/signup/', google_signup, name='google_signup'),
    path('logout/', logout_view, name='logout'),
    path('index/', index, name='index'),
    path('forgot_password/', forgot_password, name='forgot_password'),
    path('reset/<uidb64>/<token>/', auth_views.PasswordResetConfirmView.as_view(), name='password_reset_confirm'),  # Add this line for password reset confirmation
    # Add other URL patterns as necessary
]
