from django import forms
from .models import Playlist

class PlaylistEditForm(forms.ModelForm):
    class Meta:
        model = Playlist
        fields = ['name', 'description']
