from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from .models import Playlist, PlaylistItem
from history.models import VideoHistory
from . import forms


@login_required
def playlist_detail_view(request, id):
    playlist = Playlist.objects.get(id=id)
    items = playlist.playlistitem_set.all()
    if request.method == 'POST':
        form = forms.PlaylistEditForm(request.POST, instance=playlist)
        if form.is_valid():
            form.save()
            return redirect('playlist:detail', id=id)
    else:
        form = forms.PlaylistEditForm(instance=playlist)
    return render(request, 'playlist/playlist_detail.html', {'playlist': playlist, 'items': items, 'form': form})

@login_required
def playlist_view(request):
    playlists = Playlist.objects.filter(user=request.user)
    return render(request, 'playlist/playlist_view.html', {'playlists': playlists})


@login_required
def create_playlist(request):
    if request.method == 'POST':
        form = forms.PlaylistForm(request.POST)

        if form.is_valid():
            playlist = form.save(commit=False)
            playlist.user = request.user
            playlist.save()
            return redirect('playlist:view')
        return redirect('playlist:create')

    form = forms.PlaylistForm()
    return render(request, 'playlist/create_playlist.html', {'form': form})

@login_required
def edit_playlist(request, playlist_id):
    playlist = Playlist.objects.get(id=playlist_id)
    if request.method == 'POST':
        form = forms.PlaylistForm(request.POST, instance=playlist)
        if form.is_valid():
            updated_playlist = form.save(commit=False)
            updated_playlist.user = request.user  # Ensure the user is the owner of the playlist
            updated_playlist.save()
            print("Playlist updated:", updated_playlist.name)  # Debugging print statement
            return redirect('playlist:view')
        else:
            print("Form is not valid:", form.errors)  # Debugging print statement
    else:
        form = forms.PlaylistForm(instance=playlist)
    return render(request, 'playlist/edit_playlist.html', {'form': form, 'playlist': playlist})

@login_required
def delete_playlist(request, playlist_id):
    playlist = Playlist.objects.get(id=playlist_id)
    if playlist.user == request.user:
        playlist.delete()
    return redirect('playlist:view')

@login_required
def add_to_playlist(request):
    if request.method == 'POST':
        playlist_id = request.POST.get('playlist_id')
        video_id = request.POST.get('video_id')
        
        # Retrieve the playlist and video history objects
        playlist = Playlist.objects.get(id=playlist_id)
        videos = VideoHistory.objects.filter(video_id=video_id)
        
        # Iterate over the video history objects and add them to the playlist
        for video in videos:
            PlaylistItem.objects.get_or_create(playlist=playlist, video=video)
        
    return redirect('playlist:view')

@login_required
def remove_from_playlist(request, playlist_id, playlist_item_id):
    playlist_item = PlaylistItem.objects.get(id=playlist_item_id)
    if playlist_item.playlist.user == request.user:
        playlist_item.delete()
    return redirect('playlist:view')
