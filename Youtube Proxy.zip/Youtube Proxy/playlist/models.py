# models.py

from django.db import models
from account.models import CustomUser
from history.models import VideoHistory

class Playlist(models.Model):
    user = models.ForeignKey(CustomUser, on_delete=models.CASCADE)
    name = models.CharField(max_length=255)
    description = models.TextField(blank=True, null=True)

    def __str__(self):
        return self.name

class PlaylistItem(models.Model):
    playlist = models.ForeignKey(Playlist, on_delete=models.CASCADE)
    video = models.ForeignKey(VideoHistory, on_delete=models.CASCADE)

    class Meta:
        unique_together = ['video', 'playlist']

    def __str__(self):
        return f'{self.playlist.name} - {self.video.title}'
