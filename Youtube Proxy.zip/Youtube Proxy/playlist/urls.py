from django.urls import path
from .views import (
    playlist_view,
    create_playlist,
    delete_playlist,
    add_to_playlist,
    remove_from_playlist,
    playlist_detail_view,
    edit_playlist  # Import the view for editing playlists
)

app_name = 'playlist'

urlpatterns = [
    path('view/', playlist_view, name='view'),
    path('view/<id>/', playlist_detail_view, name='detail'),
    path('create_playlist/', create_playlist, name='create'),
    path('edit/<int:playlist_id>/', edit_playlist, name='edit'),  # Add URL pattern for editing playlists
    path('delete/<int:playlist_id>/', delete_playlist, name='delete'),
    path('add/', add_to_playlist, name='add'),
    path('remove/<int:playlist_id>/<int:playlist_item_id>/', remove_from_playlist, name='remove'),
]

