from django import forms
from .models import Playlist
from . import models
from django import forms

class PlaylistEditForm(forms.ModelForm):
    class Meta:
        model = models.Playlist
        fields = ['name', 'description']


class PlaylistForm(forms.ModelForm):
    class Meta:
        model = Playlist
        fields = ['name', 'description']
